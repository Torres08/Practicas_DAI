
## Pasos

correr
❯ npm run dev

1. Instalar Vite y crear un nuevo proyecto:
npm create vite@latest mi-tienda --template react

cd mi-tienda

2. Instalar Tailwind CSS y daisyUI:
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
npm install daisyui


3. Configurar Tailwind CSS: En tailwind.config.js, añade daisyui al array de plugins:

4. ProductList.jsx
5. App.jsx